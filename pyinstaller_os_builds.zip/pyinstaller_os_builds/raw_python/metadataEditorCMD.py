import re
import sys
import piexif
from PIL import Image
import os
from datetime import datetime
import time
from pathlib import Path
from dotenv import load_dotenv

if getattr(sys, 'frozen', False):
    base_dir = Path(sys.executable).parent
else:
    base_dir = Path(__file__).parent

load_dotenv(f'{base_dir}/config')


IMAGES_FOLDER = os.getenv("IMAGES_FOLDER", '/')
OUTPUT_LOG_FILE = os.getenv("OUTPUT_LOG_FILE")
SUPRESS_ERRORS = os.getenv("SUPRESS_ERRORS", 'False').lower() in ("true", "1", "yes")
CAMERA_MAKE = os.getenv("CAMERA_MAKE", "Unknown Camera Make")
CAMERA_MODEL = os.getenv("CAMERA_MODEL", "Unknown Camera Model")
WHITEBALANCE = os.getenv("WHITEBALANCE", 0)
FOCAL_LENGTH = os.getenv("FOCAL_LENGTH", 50)
ISO_SPEED = os.getenv("ISO_SPEED", 100)
APERTURE = os.getenv("APERTURE", 28)

FRAME_NUMBER = int(os.getenv('FRAME_NUMBER', 3))
if FRAME_NUMBER == 3:
    FRAME_ORDER = os.getenv("3FRAME_ORDER", "under,over,normal")
else:
    FRAME_ORDER = os.getenv("5FRAME_ORDER", "under,mild_under,normal,mild_over,over")
FRAME_ORDER = FRAME_ORDER.split(',')
VALID_EXTENSIONS = os.getenv("VALID_EXTENSIONS", ".jpg,.tif,.tiff,.png,.jpeg,.dng,.cr2,.nef,.arw")
VALID_EXTENSIONS = VALID_EXTENSIONS.split(',')

UNDER_EXPOSURE_TIME = os.getenv("UNDER_EXPOSURE_TIME", 500)
UNDER_EXPOSURE_BIAS = os.getenv("UNDER_EXPOSURE_BIAS", -2)

MILD_UNDER_EXPOSURE_TIME = os.getenv('MILD_UNDER_EXPOSURE_TIME', 250)
MILD_UNDER_EXPOSURE_BIAS = os.getenv("MILD_UNDER_EXPOSURE_BIAS", -1)

NORMAL_EXPOSURE_TIME = os.getenv("NORMAL_EXPOSURE_TIME", 125)
NORMAL_EXPOSURE_BIAS = os.getenv("NORMAL_EXPOSURE_BIAS", 0)

MILD_OVER_EXPOSURE_TIME= os.getenv("MILD_OVER_EXPOSURE_TIME", 60)
MILD_OVER_EXPOSURE_BIAS=os.getenv("MILD_OVER_EXPOSURE_BIAS", -1)

OVER_EXPOSURE_TIME = os.getenv("OVER_EXPOSURE_TIME", 30)
OVER_EXPOSURE_BIAS = os.getenv("OVER_EXPOSURE_BIAS", 2)



def convert_to_float(name, value):
    try:
        v = float(value)
        return v
    except Exception:
        print(f'Error. {name} must be a number. {value} is not a correct value')

def convert_to_int(name, value):
    try:
        v = int(value)
        return v
    except Exception:
        print(f'Error. {name} must be a number. {value} is not a correct value')



UNDER_EXPOSURE_TIME = convert_to_int("UNDER_EXPOSURE_TIME", UNDER_EXPOSURE_TIME)
UNDER_EXPOSURE_BIAS = convert_to_int("UNDER_EXPOSURE_BIAS", UNDER_EXPOSURE_BIAS)
MILD_UNDER_EXPOSURE_TIME = convert_to_int("MILD_UNDER_EXPOSURE_TIME", MILD_UNDER_EXPOSURE_TIME)
MILD_UNDER_EXPOSURE_BIAS = convert_to_int("MILD_UNDER_EXPOSURE_BIAS", MILD_UNDER_EXPOSURE_BIAS)
NORMAL_EXPOSURE_TIME = convert_to_int("NORMAL_EXPOSURE_TIME", NORMAL_EXPOSURE_TIME)
NORMAL_EXPOSURE_BIAS = convert_to_int("NORMAL_EXPOSURE_BIAS", NORMAL_EXPOSURE_BIAS)
MILD_OVER_EXPOSURE_TIME = convert_to_int("MILD_OVER_EXPOSURE_TIME", MILD_OVER_EXPOSURE_TIME)
MILD_OVER_EXPOSURE_BIAS = convert_to_int("MILD_OVER_EXPOSURE_BIAS", MILD_OVER_EXPOSURE_BIAS)
OVER_EXPOSURE_TIME = convert_to_int("OVER_EXPOSURE_TIME", OVER_EXPOSURE_TIME)
OVER_EXPOSURE_BIAS = convert_to_int("OVER_EXPOSURE_BIAS", OVER_EXPOSURE_BIAS)
WHITEBALANCE = convert_to_int("WHITEBALANCE", WHITEBALANCE)
FOCAL_LENGTH = convert_to_int("FOCAL_LENGTH", FOCAL_LENGTH)
ISO_SPEED = convert_to_int("ISO_SPEED", ISO_SPEED)
APERTURE = convert_to_int("APERTURE", APERTURE)


def preview_mode():
    print('\nHere are the metadata changes to be added to the images:')
    print(f'Camera Make: {CAMERA_MAKE}\nCamera Model: {CAMERA_MODEL}')
    print(f"White Balance: {WHITEBALANCE}\nFocal Length: {FOCAL_LENGTH}mm")
    print(f"ISO Speed Ratings: {ISO_SPEED}\nAperture/FNumber: {APERTURE}/10")

    print('--------- UNDER FRAME ----------')
    print(f'Exposure Time: 1/{UNDER_EXPOSURE_TIME}\nExposure Bias: {UNDER_EXPOSURE_BIAS} EV')

    if FRAME_NUMBER != 3:
        print('--------- MILD UNDER FRAME ----------')
        print(f'Exposure Time: 1/{MILD_UNDER_EXPOSURE_TIME}\nExposure Bias: {MILD_UNDER_EXPOSURE_BIAS} EV')

    print('--------- NORMAL FRAME ----------')
    print(f'Exposure Time: 1/{NORMAL_EXPOSURE_TIME}\nExposure Bias: {NORMAL_EXPOSURE_BIAS} EV')

    if FRAME_NUMBER != 3:
        print('--------- MILD OVER FRAME ----------')
        print(f'Exposure Time: 1/{MILD_OVER_EXPOSURE_TIME}\nExposure Bias: {MILD_OVER_EXPOSURE_BIAS} EV')
    
    print('--------- OVER FRAME ----------')
    print(f'Exposure Time: 1/{OVER_EXPOSURE_TIME}\nExposure Bias: {OVER_EXPOSURE_BIAS} EV')
    
    print("Are you okay with these changes?")
    answer = input("Continue processing? (y/n): ")
    if answer.lower() != 'yes' and answer.lower() != 'y':
        print('Aborting...')
        return False
    return True
    

def validate_config_values():
    # Validate Config Values
    if not IMAGES_FOLDER:
        print("Error. Missing Config Value: IMAGES_FOLDER")
        print("Please Specify the folder containing the images Images in the .env config file")
        return False
    return True


hdr_metadata = {
    "under": {
        "ExposureTime": UNDER_EXPOSURE_TIME,       # Exposure time: 1/200s
        "ExposureBiasValue": UNDER_EXPOSURE_BIAS,  # Exposure bias: -2 EV
    },
    "mild_under": {
        "ExposureTime": (1, MILD_UNDER_EXPOSURE_TIME),       # Exposure time: 1/200s
        "ExposureBiasValue": (MILD_UNDER_EXPOSURE_BIAS, 1),  # Exposure bias: -2 EV
    },
    "normal": {
        "ExposureTime": NORMAL_EXPOSURE_TIME,      # Exposure time: 1/100s
        "ExposureBiasValue": NORMAL_EXPOSURE_BIAS,   # Exposure bias: 0 EV
    },
    "mild_over": {
        "ExposureTime": (1, MILD_OVER_EXPOSURE_TIME),       # Exposure time: 1/50s
        "ExposureBiasValue": (MILD_OVER_EXPOSURE_BIAS, 1),   # Exposure bias: +2 EV
    },
    "over": {
        "ExposureTime": OVER_EXPOSURE_TIME,       # Exposure time: 1/50s
        "ExposureBiasValue": OVER_EXPOSURE_BIAS,   # Exposure bias: +2 EV
    },
}

# "FNumber": (APERTURE, 10),           # Aperture: f/2.8
# "ISOSpeedRatings": ISO_SPEED,        # ISO 100

def add_exif_(image_path, type, date):
    metadata = hdr_metadata.get(type)
    if not metadata:
        return
    bracket_date = datetime.now()
    bracket_date = bracket_date.strftime("%Y:%m:%d %H:%M:%S")
    
    # Build EXIF dictionary
    exif_dict = {
        "Exif": {
            piexif.ExifIFD.ExposureTime: (1, metadata["ExposureTime"]),
            piexif.ExifIFD.ShutterSpeedValue: (1, metadata["ExposureTime"]),
            piexif.ExifIFD.FNumber: (APERTURE, 10),
            piexif.ExifIFD.ISOSpeedRatings: ISO_SPEED,
            piexif.ExifIFD.ExposureBiasValue: (metadata["ExposureBiasValue"], 1),
            piexif.ExifIFD.FocalLength: (FOCAL_LENGTH, 1),
            piexif.ExifIFD.ExposureMode: 0,
            piexif.ExifIFD.WhiteBalance: WHITEBALANCE, 
	    piexif.ExifIFD.DateTimeOriginal: bracket_date.encode("utf-8") 
        },
        "0th": {
            piexif.ImageIFD.Make: 'Canon',
            piexif.ImageIFD.Model: 'Canon EOS 5D Mark IV',  
            piexif.ImageIFD.DateTime: bracket_date.encode("utf-8"),
        },
    }

    # Convert EXIF dictionary to bytes
    exif_bytes = piexif.dump(exif_dict)

    # Open the image and save with updated EXIF data
    image = Image.open(f"{IMAGES_FOLDER}/{image_path}")
    image.save(f"{IMAGES_FOLDER}/{image_path}", exif=exif_bytes)


filename_sequence = []

def extract_leading_number(filename):
    match = re.match(r"(\d+)", filename)  # Match leading numbers
    result = int(match.group(1)) if match else float('inf')
    filename_sequence.append(result)
    return result


def sort_all_filenames_in_folder_numerically():
    image_filenames = [
        filename for filename in os.listdir(IMAGES_FOLDER)
        if os.path.isfile(os.path.join(IMAGES_FOLDER, filename)) and any(filename.lower().endswith(ext) for ext in VALID_EXTENSIONS)
    ]
    return sorted(image_filenames, key=extract_leading_number)

def make_sure_all_images_are_present(arr):
    lowest = min(arr)
    highest = max(arr)
    expected_numbers = set(range(lowest, highest + 1))
    missing_numbers = expected_numbers - set(arr)
    if missing_numbers:
        print(f"MISSING FRAME(s) (starts with): {sorted(missing_numbers)}")
        print('Error: Frame(s) missing in the sequence. Please check your IMAGE FOLDER and make sure all frames are present in their correct order.')
        input('Press any key to continue: ')
        return False
    return True


def filter_broken_brackets(filenames, group_size):
    """
    Filters a list of numerically sorted filenames, removing groups where a member is missing.

    Args:
      filenames: A list of filenames, assumed to be numerically sorted.
      group_size: The size of the groups to consider.

    Returns:
      A list of filenames with missing groups removed.
    """
    print("Skipping broken brackets")
    filtered_filenames = []
    start = 0
    while start < len(filenames):
        bracket_start = extract_leading_number(filenames[start])
        bracket_end = bracket_start + group_size - 1 # the number the current bracket should end at
        try:
            file_at_end = extract_leading_number(filenames[start + group_size -1])
        except: # If we have reached the end of the filenames array
            break
        if file_at_end == bracket_end:
            for i in range(start, (start+group_size)):
                filtered_filenames.append(filenames[i])
        else:
            next_supposed_file = bracket_start + group_size
            found = False
            while not found and next_supposed_file < len(filenames):
                for i in range(start, len(filenames)):
                    if extract_leading_number(filenames[i]) == next_supposed_file:
                        start = i
                        found = True
                        break
                next_supposed_file = next_supposed_file + group_size
            continue
        start = start + group_size
    return filtered_filenames




def add_exif(image_path, type):



    bracket_date = datetime.now()
    bracket_date = bracket_date.strftime("%Y:%m:%d %H:%M:%S")
    # EXIF data to set
    if type == 'over':
        exif_data = {
            "ExposureTime": (1, 5),  # 5 seconds
            "FNumber": (63, 10),  # f/6.3
            "ExposureProgram": 3,  # Aperture-priority AE
            "ISO": 100,
            "SensitivityType": 2,  # Recommended Exposure Index
            "RecommendedExposureIndex": 100,
            "ExifVersion": b'\x02\x03\x00\x00',  # Exif Version 0230
            "DateTimeOriginal": bracket_date,
            "CreateDate": bracket_date,
            "ShutterSpeedValue": (1, 5),
            "ApertureValue": (63, 10),
            "ExposureCompensation": (2, 1),  # +2 EV (in 1/3 EV steps, so 200 means +2 EV)
            "MaxApertureValue": (40, 10),  # f/4.0
            "MeteringMode": 5,  # Multi-segment
            "Flash": 0,  # Off, Did not fire
            "FocalLength": (160, 10),  # 16.0 mm
            "SubSecTimeOriginal": "14",
            "SubSecTimeDigitized": "14",
            "ColorSpace": 1,  # sRGB
            "FocalPlaneXResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneYResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneResolutionUnit": 2,  # cm
            "CustomRendered": 0,  # Normal
            "ExposureMode": 0,  # Auto bracket
            "WhiteBalance": 0,  # Auto
            "SceneCaptureType": 0,  # Standard
            "OwnerName": "Wojciech Toman",
            "SerialNumber": "013021003506",
            "LensInfo": "(16-35mm f/?)",
            "LensModel": "EF16-35mm f/4L IS USM",
            "LensSerialNumber": "2300003109",
        }
    if type == 'under':
        exif_data = {
            "ExposureTime": (1, 6),  # 1/6 seconds
            "FNumber": (63, 10),  # f/6.3
            "ExposureProgram": 3,  # Aperture-priority AE
            "ISO": 100,
            "SensitivityType": 2,  # Recommended Exposure Index
            "RecommendedExposureIndex": 100,
            "ExifVersion": b'\x02\x03\x00\x00',  # Exif Version 0230
            "DateTimeOriginal": bracket_date,
            "CreateDate": bracket_date,
            "ShutterSpeedValue": (1, 6),  # 1/6 seconds
            "ApertureValue": (63, 10),  # f/6.3
            "ExposureCompensation": (-3, 1),  # -3 EV (in 1/3 EV steps, so -300 means -3 EV)
            "MaxApertureValue": (40, 10),  # f/4.0
            "MeteringMode": 5,  # Multi-segment
            "Flash": 0,  # Off, Did not fire
            "FocalLength": (160, 10),  # 16.0 mm
            "SubSecTimeOriginal": "67",
            "SubSecTimeDigitized": "67",
            "ColorSpace": 1,  # sRGB
            "FocalPlaneXResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneYResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneResolutionUnit": 2,  # cm
            "CustomRendered": 0,  # Normal
            "ExposureMode": 0,  # Auto bracket
            "WhiteBalance": 0,  # Auto
            "SceneCaptureType": 0,  # Standard
            "OwnerName": "Wojciech Toman",
            "SerialNumber": "013021003506",
            "LensInfo": "(16-35mm f/?)",
            "LensModel": "EF16-35mm f/4L IS USM",
            "LensSerialNumber": "2300003109",
        }
    if type == 'normal':
        exif_data = {
            "ExposureTime": (13, 10),  # 1.3 seconds
            "FNumber": (63, 10),  # f/6.3
            "ExposureProgram": 3,  # Aperture-priority AE
            "ISO": 100,
            "SensitivityType": 2,  # Recommended Exposure Index
            "RecommendedExposureIndex": 100,
            "ExifVersion": b'\x02\x03\x00\x00',  # Exif Version 0230
            "DateTimeOriginal": bracket_date,
            "CreateDate": bracket_date,
            "ShutterSpeedValue": (13, 10),  # 1.3 seconds
            "ApertureValue": (63, 10),  # f/6.3
            "ExposureCompensation": (0, 1),  # 0 EV
            "MaxApertureValue": (40, 10),  # f/4.0
            "MeteringMode": 5,  # Multi-segment
            "Flash": 0,  # Off, Did not fire
            "FocalLength": (160, 10),  # 16.0 mm
            "SubSecTimeOriginal": "21",
            "SubSecTimeDigitized": "21",
            "ColorSpace": 1,  # sRGB
            "FocalPlaneXResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneYResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneResolutionUnit": 2,  # cm
            "CustomRendered": 0,  # Normal
            "ExposureMode": 0,  # Auto bracket
            "WhiteBalance": 0,  # Auto
            "SceneCaptureType": 0,  # Standard
            "OwnerName": "Wojciech Toman",
            "SerialNumber": "013021003506",
            "LensInfo": "16-35mm f/?",
            "LensModel": "EF16-35mm f/4L IS USM",
            "LensSerialNumber": "2300003109",
        }



    # Load image
    image = Image.open(f"{IMAGES_FOLDER}/{image_path}")
    exif_dict = {}
    # Get the current EXIF data
    if image.info.get("exif"):
        exif_dict = piexif.load(image.info.get("exif"))

    if "0th" not in exif_dict:
        exif_dict["0th"] = {}
    if "Exif" not in exif_dict:
        exif_dict['Exif'] = {}
    # Prepare the EXIF data
    exif_dict["0th"][piexif.ImageIFD.Make] = "Wojciech Toman"
    exif_dict["Exif"][0x9003] = exif_data.get("DateTimeOriginal", "")  # DateTimeOriginal
    exif_dict["Exif"][0x9004] = exif_data.get("CreateDate", "")  # CreateDate
    exif_dict["Exif"][0x829D] = exif_data.get("FNumber", (0, 0))  # FNumber (Fraction form: numerator/denominator)
    exif_dict["Exif"][0x829A] = exif_data.get("ExposureTime", (0, 0))  # ExposureTime (Fraction form)
    exif_dict["Exif"][0x8827] = exif_data.get("ISO", 0)  # ISOSpeedRatings
    exif_dict["Exif"][0x8822] = exif_data.get("ExposureProgram", 0)  # ExposureProgram
    exif_dict["Exif"][0x9204] = exif_data.get("ExposureCompensation", 0)  # ExposureCompensation
    exif_dict["Exif"][0x9207] = exif_data.get("MeteringMode", 0)  # MeteringMode
    exif_dict["Exif"][0x9209] = exif_data.get("Flash", 0)  # Flash
    exif_dict["Exif"][0x920A] = exif_data.get("FocalLength", (0, 0))  # FocalLength
    exif_dict["Exif"][0xA20E] = exif_data.get("FocalPlaneXResolution", 0)  # FocalPlaneXResolution
    exif_dict["Exif"][0xA20F] = exif_data.get("FocalPlaneYResolution", 0)  # FocalPlaneYResolution
    exif_dict["Exif"][0xA210] = exif_data.get("FocalPlaneResolutionUnit", 0)  # FocalPlaneResolutionUnit
    exif_dict["Exif"][0xA401] = exif_data.get("CustomRendered", 0)  # CustomRendered
    exif_dict["Exif"][0xA402] = exif_data.get("ExposureMode", 0)  # ExposureMode
    exif_dict["Exif"][0xA403] = exif_data.get("WhiteBalance", 0)  # WhiteBalance
    exif_dict["Exif"][0xA406] = exif_data.get("SceneCaptureType", 0)  # SceneCaptureType
    # exif_dict["Exif"][0xA432] = exif_data.get("LensModel", "")  # LensModel
    exif_dict["Exif"][0xA433] = exif_data.get("LensSerialNumber", "")  # LensSerialNumber
    exif_dict["Exif"][0xA434] = exif_data.get("LensInfo", "")  # LensInfo
    # exif_dict["Exif"][0xF000] = exif_data.get("SerialNumber", "")  # SerialNumber
    # exif_dict["Exif"][0xF001] = exif_data.get("OwnerName", "")  # OwnerName

    # Write the updated EXIF back to the image
    exif_bytes = piexif.dump(exif_dict)
    image.save(f"{IMAGES_FOLDER}/{image_path}", exif=exif_bytes)

def main():
    print(f'\nProcessing images from Folder: {"Current directory" if IMAGES_FOLDER == "/" else IMAGES_FOLDER}')
    print(f"Image frame pattern is: {FRAME_ORDER}\n")
    frame_number = 0
    bracket_date = None

    sorted_filenames = sort_all_filenames_in_folder_numerically()
    if len(sorted_filenames) == 0:
        print("No image found")
        input("Press Any key to Abort: ")
        return

    proceed = make_sure_all_images_are_present(filename_sequence)
    
    for i in range(0, len(sorted_filenames)):
        filename = sorted_filenames[i]
        if frame_number == 0:
            print('processing', [sorted_filenames[i+j] for j in range(0, FRAME_NUMBER) if i+j < len(sorted_filenames)])
            time.sleep(1)
            bracket_date = datetime.now()
            bracket_date = bracket_date.strftime("%Y:%m:%d %H:%M:%S")
        
        add_exif(filename, FRAME_ORDER[frame_number])
        frame_number += 1
        if frame_number > FRAME_NUMBER - 1:
            frame_number = 0
    print("Completed")

def run():
    proceed = preview_mode()
    if not proceed:
        return
            
    proceed = validate_config_values()
    if proceed:
        main()

if __name__ == '__main__':
    run()
