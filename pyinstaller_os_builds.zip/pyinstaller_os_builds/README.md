# pyinstaller_os_builds
This is a repo to test github's CI/CD for building standalone python applications for all os
