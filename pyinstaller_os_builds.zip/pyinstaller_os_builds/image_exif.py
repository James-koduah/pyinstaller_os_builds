import re
import piexif
from PIL import Image
import os


def add_exif_(folder_path, image_path, metadata, frame_data, date, output_folder=False):
    
    # Build EXIF dictionary
    exif_dict = {
        "Exif": {
            piexif.ExifIFD.ExposureTime: (1, frame_data.get('exposure_time')),
            piexif.ExifIFD.FNumber: (metadata.get('aperture'), 10),
            piexif.ExifIFD.ISOSpeedRatings: metadata.get('iso_speed'),
            piexif.ExifIFD.ExposureBiasValue: (frame_data.get('exposure_bias'), 1),
            piexif.ExifIFD.FocalLength: (metadata.get('focal_length'), 1),
            piexif.ExifIFD.WhiteBalance: metadata.get('white_balance'), 
        },
        "0th": {
            piexif.ImageIFD.Make: metadata.get('camera_make'),
            piexif.ImageIFD.Model: metadata.get('camera_model'),  
            piexif.ImageIFD.DateTime: date,
        },
    }

    # Convert EXIF dictionary to bytes
    exif_bytes = piexif.dump(exif_dict)

    # Open the image and save with updated EXIF data
    image = Image.open(f"{folder_path}/{image_path}")
    if output_folder:
        try:
            image.save(f"{output_folder}/{image_path}", exif=exif_bytes)
        except Exception as e:
            pass
    else:
        image.save(f"{folder_path}/{image_path}", exif=exif_bytes)



def add_exif(folder_path, image_path, type, output_folder=False):
    bracket_date = datetime.now()
    bracket_date = bracket_date.strftime("%Y:%m:%d %H:%M:%S")
    # EXIF data to set
    if type == 'over':
        exif_data = {
            "ExposureTime": (1, 5),  # 5 seconds
            "FNumber": (63, 10),  # f/6.3
            "ExposureProgram": 3,  # Aperture-priority AE
            "ISO": 100,
            "SensitivityType": 2,  # Recommended Exposure Index
            "RecommendedExposureIndex": 100,
            "ExifVersion": b'\x02\x03\x00\x00',  # Exif Version 0230
            "DateTimeOriginal": bracket_date,
            "CreateDate": bracket_date,
            "ShutterSpeedValue": (1, 5),
            "ApertureValue": (63, 10),
            "ExposureCompensation": (2, 1),  # +2 EV (in 1/3 EV steps, so 200 means +2 EV)
            "MaxApertureValue": (40, 10),  # f/4.0
            "MeteringMode": 5,  # Multi-segment
            "Flash": 0,  # Off, Did not fire
            "FocalLength": (160, 10),  # 16.0 mm
            "SubSecTimeOriginal": "14",
            "SubSecTimeDigitized": "14",
            "ColorSpace": 1,  # sRGB
            "FocalPlaneXResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneYResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneResolutionUnit": 2,  # cm
            "CustomRendered": 0,  # Normal
            "ExposureMode": 0,  # Auto bracket
            "WhiteBalance": 0,  # Auto
            "SceneCaptureType": 0,  # Standard
            "OwnerName": "Wojciech Toman",
            "SerialNumber": "013021003506",
            "LensInfo": "(16-35mm f/?)",
            "LensModel": "EF16-35mm f/4L IS USM",
            "LensSerialNumber": "2300003109",
        }

    if type == 'mild_over':
        exif_data = {
            "ExposureTime": (1, 3),  # 5 seconds
            "FNumber": (63, 10),  # f/6.3
            "ExposureProgram": 3,  # Aperture-priority AE
            "ISO": 100,
            "SensitivityType": 2,  # Recommended Exposure Index
            "RecommendedExposureIndex": 100,
            "ExifVersion": b'\x02\x03\x00\x00',  # Exif Version 0230
            "DateTimeOriginal": bracket_date,
            "CreateDate": bracket_date,
            "ShutterSpeedValue": (1, 5),
            "ApertureValue": (63, 10),
            "ExposureCompensation": (2, 1),  # +2 EV (in 1/3 EV steps, so 200 means +2 EV)
            "MaxApertureValue": (40, 10),  # f/4.0
            "MeteringMode": 5,  # Multi-segment
            "Flash": 0,  # Off, Did not fire
            "FocalLength": (160, 10),  # 16.0 mm
            "SubSecTimeOriginal": "14",
            "SubSecTimeDigitized": "14",
            "ColorSpace": 1,  # sRGB
            "FocalPlaneXResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneYResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneResolutionUnit": 2,  # cm
            "CustomRendered": 0,  # Normal
            "ExposureMode": 0,  # Auto bracket
            "WhiteBalance": 0,  # Auto
            "SceneCaptureType": 0,  # Standard
            "OwnerName": "Wojciech Toman",
            "SerialNumber": "013021003506",
            "LensInfo": "(16-35mm f/?)",
            "LensModel": "EF16-35mm f/4L IS USM",
            "LensSerialNumber": "2300003109",
        }
    if type == 'under':
        exif_data = {
            "ExposureTime": (1, 6),  # 1/6 seconds
            "FNumber": (63, 10),  # f/6.3
            "ExposureProgram": 3,  # Aperture-priority AE
            "ISO": 100,
            "SensitivityType": 2,  # Recommended Exposure Index
            "RecommendedExposureIndex": 100,
            "ExifVersion": b'\x02\x03\x00\x00',  # Exif Version 0230
            "DateTimeOriginal": bracket_date,
            "CreateDate": bracket_date,
            "ShutterSpeedValue": (1, 6),  # 1/6 seconds
            "ApertureValue": (63, 10),  # f/6.3
            "ExposureCompensation": (-3, 1),  # -3 EV (in 1/3 EV steps, so -300 means -3 EV)
            "MaxApertureValue": (40, 10),  # f/4.0
            "MeteringMode": 5,  # Multi-segment
            "Flash": 0,  # Off, Did not fire
            "FocalLength": (160, 10),  # 16.0 mm
            "SubSecTimeOriginal": "67",
            "SubSecTimeDigitized": "67",
            "ColorSpace": 1,  # sRGB
            "FocalPlaneXResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneYResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneResolutionUnit": 2,  # cm
            "CustomRendered": 0,  # Normal
            "ExposureMode": 0,  # Auto bracket
            "WhiteBalance": 0,  # Auto
            "SceneCaptureType": 0,  # Standard
            "OwnerName": "Wojciech Toman",
            "SerialNumber": "013021003506",
            "LensInfo": "(16-35mm f/?)",
            "LensModel": "EF16-35mm f/4L IS USM",
            "LensSerialNumber": "2300003109",
        }
    if type == 'normal':
        exif_data = {
            "ExposureTime": (13, 10),  # 1.3 seconds
            "FNumber": (63, 10),  # f/6.3
            "ExposureProgram": 3,  # Aperture-priority AE
            "ISO": 100,
            "SensitivityType": 2,  # Recommended Exposure Index
            "RecommendedExposureIndex": 100,
            "ExifVersion": b'\x02\x03\x00\x00',  # Exif Version 0230
            "DateTimeOriginal": bracket_date,
            "CreateDate": bracket_date,
            "ShutterSpeedValue": (13, 10),  # 1.3 seconds
            "ApertureValue": (63, 10),  # f/6.3
            "ExposureCompensation": (0, 1),  # 0 EV
            "MaxApertureValue": (40, 10),  # f/4.0
            "MeteringMode": 5,  # Multi-segment
            "Flash": 0,  # Off, Did not fire
            "FocalLength": (160, 10),  # 16.0 mm
            "SubSecTimeOriginal": "21",
            "SubSecTimeDigitized": "21",
            "ColorSpace": 1,  # sRGB
            "FocalPlaneXResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneYResolution": (1866667, 1000),  # 1866.666656 cm
            "FocalPlaneResolutionUnit": 2,  # cm
            "CustomRendered": 0,  # Normal
            "ExposureMode": 0,  # Auto bracket
            "WhiteBalance": 0,  # Auto
            "SceneCaptureType": 0,  # Standard
            "OwnerName": "Wojciech Toman",
            "SerialNumber": "013021003506",
            "LensInfo": "16-35mm f/?",
            "LensModel": "EF16-35mm f/4L IS USM",
            "LensSerialNumber": "2300003109",
        }



    # Load image
    image = Image.open(f"{IMAGES_FOLDER}/{image_path}")
    exif_dict = {}
    # Get the current EXIF data
    if image.info.get("exif"):
        exif_dict = piexif.load(image.info.get("exif"))

    if "0th" not in exif_dict:
        exif_dict["0th"] = {}
    if "Exif" not in exif_dict:
        exif_dict['Exif'] = {}
    # Prepare the EXIF data
    exif_dict["0th"][piexif.ImageIFD.Make] = "Wojciech Toman"
    exif_dict["Exif"][0x9003] = exif_data.get("DateTimeOriginal", "")  # DateTimeOriginal
    exif_dict["Exif"][0x9004] = exif_data.get("CreateDate", "")  # CreateDate
    exif_dict["Exif"][0x829D] = exif_data.get("FNumber", (0, 0))  # FNumber (Fraction form: numerator/denominator)
    exif_dict["Exif"][0x829A] = exif_data.get("ExposureTime", (0, 0))  # ExposureTime (Fraction form)
    exif_dict["Exif"][0x8827] = exif_data.get("ISO", 0)  # ISOSpeedRatings
    exif_dict["Exif"][0x8822] = exif_data.get("ExposureProgram", 0)  # ExposureProgram
    exif_dict["Exif"][0x9204] = exif_data.get("ExposureCompensation", 0)  # ExposureCompensation
    exif_dict["Exif"][0x9207] = exif_data.get("MeteringMode", 0)  # MeteringMode
    exif_dict["Exif"][0x9209] = exif_data.get("Flash", 0)  # Flash
    exif_dict["Exif"][0x920A] = exif_data.get("FocalLength", (0, 0))  # FocalLength
    exif_dict["Exif"][0xA20E] = exif_data.get("FocalPlaneXResolution", 0)  # FocalPlaneXResolution
    exif_dict["Exif"][0xA20F] = exif_data.get("FocalPlaneYResolution", 0)  # FocalPlaneYResolution
    exif_dict["Exif"][0xA210] = exif_data.get("FocalPlaneResolutionUnit", 0)  # FocalPlaneResolutionUnit
    exif_dict["Exif"][0xA401] = exif_data.get("CustomRendered", 0)  # CustomRendered
    exif_dict["Exif"][0xA402] = exif_data.get("ExposureMode", 0)  # ExposureMode
    exif_dict["Exif"][0xA403] = exif_data.get("WhiteBalance", 0)  # WhiteBalance
    exif_dict["Exif"][0xA406] = exif_data.get("SceneCaptureType", 0)  # SceneCaptureType
    # exif_dict["Exif"][0xA432] = exif_data.get("LensModel", "")  # LensModel
    exif_dict["Exif"][0xA433] = exif_data.get("LensSerialNumber", "")  # LensSerialNumber
    exif_dict["Exif"][0xA434] = exif_data.get("LensInfo", "")  # LensInfo
    # exif_dict["Exif"][0xF000] = exif_data.get("SerialNumber", "")  # SerialNumber
    # exif_dict["Exif"][0xF001] = exif_data.get("OwnerName", "")  # OwnerName

    # Write the updated EXIF back to the image
    exif_bytes = piexif.dump(exif_dict)
    image.save(f"{IMAGES_FOLDER}/{image_path}", exif=exif_bytes)

# filename_sequence = []

def extract_leading_number(filename):
    match = re.match(r"(\d+)", filename)  # Match leading numbers
    result = int(match.group(1)) if match else float('inf')
    return result


def sort_all_filenames_in_folder_numerically(images_folder):
    image_filenames = [
        filename for filename in os.listdir(images_folder)
        if os.path.isfile(os.path.join(images_folder, filename)) and any(filename.lower().endswith(ext) for ext in ['.jpg', '.tif', '.tiff', '.png', '.jpeg', '.dng', '.cr2', '.nef', '.arw'])
    ]
    return sorted(image_filenames, key=extract_leading_number)

def filter_broken_brackets(filenames, group_size):
    """
    Filters a list of numerically sorted filenames, removing groups where a member is missing.

    Args:
      filenames: A list of filenames, assumed to be numerically sorted.
      group_size: The size of the groups to consider.

    Returns:
      A list of filenames with missing groups removed.
    """

    filtered_filenames = []
    start = 0
    while start < len(filenames):
        bracket_start = extract_leading_number(filenames[start])
        bracket_end = bracket_start + group_size - 1 # the number the current bracket should end at
        try:
            file_at_end = extract_leading_number(filenames[start + group_size -1])
        except: # If we have reached the end of the filenames array
            break
        if file_at_end == bracket_end:
            for i in range(start, (start+group_size)):
                filtered_filenames.append(filenames[i])
        else:
            next_supposed_file = bracket_start + group_size
            found = False
            while not found and next_supposed_file < len(filenames):
                for i in range(start, len(filenames)):
                    if extract_leading_number(filenames[i]) == next_supposed_file:
                        start = i
                        found = True
                        break
                next_supposed_file = next_supposed_file + group_size
            continue
        start = start + group_size
    return filtered_filenames

def make_sure_all_images_are_present(raw_arr):
    arr = []
    for i in raw_arr:
        arr.append(extract_leading_number(i))
    lowest = min(arr)
    highest = max(arr)
    expected_numbers = set(range(lowest, highest + 1))
    missing_numbers = expected_numbers - set(arr)
    if missing_numbers:
        return list(missing_numbers)
    return False
